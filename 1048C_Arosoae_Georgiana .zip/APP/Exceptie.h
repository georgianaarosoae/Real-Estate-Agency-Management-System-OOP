#pragma once
#include <string>
using namespace std;
class Exceptie {
private:
	string mesajExceptie;
public:
	Exceptie(string mesajExceptie);
	string getMesajExceptie();
	
};

